# SMB AI operations suite design preparation

Design only, dated 24 October 2026 UTC. Start with:

1. [Product scope and workflows](docs/01-product-scope-and-workflows.md)
2. [Vultr architecture privacy and deployment](docs/02-vultr-architecture-privacy-and-deployment.md)
3. [Pre event provenance](PRE_EVENT_PROVENANCE.md)

Editable Markdown sources for founder review and later implementation planning. Nothing has been implemented or deployed. No commits or GitHub pushes are authorised by this preparation.
